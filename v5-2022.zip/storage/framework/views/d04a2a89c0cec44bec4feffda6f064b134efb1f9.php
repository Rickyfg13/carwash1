<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Struk Order</title>
    <style>        
        body {
            font-family: Verdana, sans-serif;
        }
        .print-area {
            margin : 5px auto;
            /* min-width: 500px; */
            /* width: 100%; */
            /* max-width: 760px; */
            /* border: 1px solid; */
        }
        .page-header {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page-header-text .title {
            font-weight: bold;
            font-size: 18px;
            color: #F79646;
            margin-bottom: 5px;
        }

        .page-header-text .address {
            font-size: 13px;
            margin-top: 0 !important;
        }
        .page-header-divider {
            border: 2px solid #F79646;
        }
        .page-body {
            margin-top: 1rem;
        }
        /* .page-body table td {
            width: 14.7rem;
        }         */
        .image-container {
            /* display: flex; */
            /* justify-content: center; */
            /* width: 100%; */
            /* flex-wrap: wrap;
            gap: 20px;
            margin: 0 auto 0;
            width:100%; */
            margin-top: 50px;
            /* display:table; */

        }
        .image-container img {
            width: 290px;            
            height: 200px;
            object-fit: cover;
            object-position: center;
            margin: 0 5px 5px;            
        }

        .grey-background-color {
            background-color: #808080;
            color: #fff;
            padding: 1px 2px 3px;
        }

        @media  print {
            /* .page-header {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .page-header-text .title {
                font-weight: bold;
                font-size: 18px;
                color: #F79646;
                margin-bottom: 5px;
                -webkit-print-color-adjust: exact;
            } */

            /* .page-body table tr.thead-orange th {
                background-color: #F79646 !important;
                color: #fff;
                -webkit-print-color-adjust: exact;
            }
            .grey-background-color {
                background-color: #808080 !important;
                color: #fff;
                -webkit-print-color-adjust: exact;
            } */
            
        }
    </style>
</head>
<!-- <body onload="window.print()"> -->


<body>
    <div class="print-area">
        <table style="margin-top: -1.5rem;">
            <tr>
                <th rowspan="2"><img src="<?php echo e(asset('img/logo1.png')); ?>" style="width: 130px;height:60px;margin-top:5px;" alt="Logo"></th>
                <td><p style="font-weight: bold; color:#F79646;font-size:18px;margin-bottom:0;">HD CARWASH</p></td>
            </tr>
            <tr>
                <td><p style="font-size:13px;margin-top:5px;">Jl. Ps. Malintang No.32, Pasa Gadang, Kec. Padang Sel., Kota Padang, Sumatera Barat (0751) 841555</p></td>            
            </tr>

        </table>
        <hr class="page-header-divider">
        <div class="page-body">
            <table style="width:100%;margin-bottom:0.5rem;">
                <tr>
                    <td align="left"><span style="font-weight: bold">No Orderan : <?php echo e($data->id); ?></span></td>
                    <td align="right"><span class="grey-background-color"><?php echo e(tgl_indo($data->created_at)); ?></span></td>
                </tr>
            </table>

            <?php
                $total = 0;
            ?>

            <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lyn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $total += $lyn->harga;
            ?>

            <table style="font-size: 12px;width:100%;margin-top:1rem;">
                <tr class="thead-orange">
                    <th style="padding: 10px 0;background: #F79646;" colspan="2">Customer</th>
                    <th style="padding: 10px 0;background: #F79646;" colspan="2">Detail Order</th>
                </tr>

                <tr>
                    <td align="left">Nama</td>
                    <td><?php echo e($data->nama); ?></td>      
                    <td align="left">Jenis Layanan</td>
                    <td></td>              
                </tr>
                <tr>
                    <td align="left">No HP</td>
                    <td><?php echo e($data->nohp); ?></td> 
                    <td align="left">Nama Layanan</td>                   
                    <td><?php echo e($lyn->nama_layanan); ?></td>
                </tr>
                <tr>
                    <td align="left">No Plat</td>
                    <td><?php echo e($data->no_kendaraan); ?></td>                    
                    <td align="left">Catatan</td>
                    <td><?php echo e($data->catatan); ?></td>
                </tr>
                <tr>
                    <td align="left">Merk Mobil</td>
                    <td><?php echo e($data->merk); ?></td>                    
                    <td align="left">Metode Pembayaran</td>
                    <td><?php echo e(is_null($data->metode_pembayaran) ? "" : loadMetodePembayaran($data->metode_pembayaran)); ?></td>                 
                </tr>                
                <tr>
                    <th></th>
                    <td></td>
                    <td align="left">Harga</td>
                    <td><?php echo e(rupiah($lyn->harga)); ?></td>
                </tr>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <table style="font-size:14px;width: 100%">
                <tr>
                    <th style="width: 12rem;"></th>
                    <td style="width: 11rem;"></td>
                    <th align="right">Total &emsp;</th>
                    <td><?php echo e(rupiah($total)); ?></td>
                </tr>
            </table>

            

            <?php if(count($gambar) > 0): ?>
            <div class="image-container">
                <?php $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e($b->path); ?>" alt="Gambar mobil yg dicuci">                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
            </div>    
            <?php endif; ?>
            
        </div>

        

        
        
    </div>


    
    
</body>

</html>
<?php /**PATH E:\Urgen\Backup-11-Des-21\htdocs-1\laravel\Pencucian-Mobil\backend\v4-2022\resources\views/finance/orderan/struk.blade.php ENDPATH**/ ?>