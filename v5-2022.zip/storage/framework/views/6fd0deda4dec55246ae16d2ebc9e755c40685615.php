

<?php $__env->startSection('content'); ?>
  <section class="body mt-3">
    <div class="row justify-content-center">
      <div class="col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-12 my-5 py-3">
        <?php if(count($orderan) == 0): ?>
        <h3 class="text-center mb-3 d-block">Tidak Ada Hasil Pencarian untuk Nomor HP "<span class="text-primary"><?php echo e('+62'.$nohp); ?></span>"</h3>
        <?php else: ?>
          <h3 class="text-center mb-3 d-block">Hasil Pencarian Nomor HP "<span class="text-primary"><?php echo e('+62'.$nohp); ?></span>"</h3>
        <?php endif; ?>
        

        <table class="table">
          <?php $__currentLoopData = $orderan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($item->nama); ?></td>
              <td align="right"><?php echo e("+62".$item->nohp); ?></td>
              <td width="20px">
                <a href="<?php echo e(url('/finance/pelanggan/histori/'.$item->id)); ?>" class="text-danger"> <i class="fa fa-search"></i> </a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        

        <div class="mt-5">
          <a href="<?php echo e(url('/finance/home')); ?>" class="btn btn-primary btn-block">Cari Lagi</a>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mobile.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stra2734/public_html/hdcarwash2.my.id/resources/views/finance/pelanggan/search-result.blade.php ENDPATH**/ ?>