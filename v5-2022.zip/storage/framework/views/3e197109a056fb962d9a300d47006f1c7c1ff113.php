<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Struk Order</title>
    <style>
        /* @font-face {
            font-family: 'quick';
            src: url(Quicksand-Regular_afda0c4733e67d13c4b46e7985d6a9ce.ttf);
        }

        * {
            font-family: 'quick';
        } */
        body {
            font-family: Verdana, sans-serif;
        }
        .print-area {
            margin : 5px auto;
            min-width: 500px;
            width: 100%;
            max-width: 760px;
            /* border: 1px solid; */
        }
        .page-header {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page-header-text .title {
            font-weight: bold;
            font-size: 18px;
            color: #F79646;
            margin-bottom: 5px;
        }

        .page-header-text .address {
            font-size: 13px;
            margin-top: 0 !important;
        }
        .page-header-divider {
            border: 2px solid #F79646;
        }
        .page-body {
            margin-top: 2rem;
        }
        /* .page-body table td {
            width: 14.7rem;
        }         */
        .image-container {
            display: flex;
            justify-content: center;
            /* width: 100%; */
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 1rem;
        }
        .image-container img {
            width: 300px;
            flex-wrap: wrap;
            height: 200px;
            object-fit: cover;
            object-position: center;
        }

        .grey-background-color {
            background-color: #808080;
            color: #fff;
        }

        @media  print {
            .page-header-text .title {
                font-weight: bold;
                font-size: 18px;
                color: #F79646;
                margin-bottom: 5px;
                -webkit-print-color-adjust: exact;
            }

            .page-body table tr.thead-orange th {
                background-color: #F79646 !important;
                color: #fff;
                -webkit-print-color-adjust: exact;
            }
            .grey-background-color {
                background-color: #808080 !important;
                color: #fff;
                -webkit-print-color-adjust: exact;
            }
            
        }
    </style>
    <style>
        .bold900 { font-weight: 900; }
    </style>
</head>
<!-- <body onload="window.print()"> -->

<body onLoad="javascript:print()">    

    <div class="print-area">
        <div class="page-header">
            <div class="page-header-asset">
                <img src="<?php echo e(asset('img/logo1.png')); ?>" style="width: 130px;height:60px" alt="">
            </div>
            <div class="page-header-text">
                <p class="title">HD CARWASH</p>
                <p class="address">Jl. Ps. Malintang No.32, Pasa Gadang, Kec. Padang Sel., Kota Padang, Sumatera Barat (0751) 841555</p>
            </div>

        </div>
        <hr class="page-header-divider">
        <div class="page-body">
            
            <div style="display: flex; justify-content:space-between; margin: 0 5px 1rem">
                <span style="font-weight: bold">No Orderan : <?php echo e($data->id); ?></span>
                <span class="grey-background-color"><?php echo e(tgl_indo($data->created_at)); ?></span>
            </div>

            <?php
                $total = 0;
            ?>

            <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lyn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $total += $lyn->harga;
            ?>

            <table style="font-size: 14px;width:100%;">
                <tr class="thead-orange">
                    <th style="padding: 10px 0;background: #F79646;" colspan="2">Customer</th>
                    <th style="padding: 10px 0;background: #F79646;" colspan="2">Detail Order</th>
                </tr>

                <tr>
                    <td align="left">Nama</td>
                    <td><?php echo e($data->nama); ?></td>      
                    <td align="left">Jenis Layanan</td>
                    <td></td>              
                </tr>
                <tr>
                    <td align="left">No HP</td>
                    <td><?php echo e($data->nohp); ?></td> 
                    <td align="left">Nama Layanan</td>                   
                    <td><?php echo e($lyn->nama_layanan); ?></td>
                </tr>
                <tr>
                    <td align="left">No Plat</td>
                    <td><?php echo e($data->no_kendaraan); ?></td>                    
                    <td align="left">Catatan</td>
                    <td><?php echo e($data->catatan); ?></td>
                </tr>
                <tr>
                    <td align="left">Merk Mobil</td>
                    <td><?php echo e($data->merk); ?></td>                    
                    <td align="left">Metode Pembayaran</td>
                    <td><?php echo e(is_null($data->metode_pembayaran) ? "" : loadMetodePembayaran($data->metode_pembayaran)); ?></td>                 
                </tr>                
                <tr>
                    <th></th>
                    <td></td>
                    <td align="left">Harga</td>
                    <td><?php echo e(rupiah($lyn->harga)); ?></td>
                </tr>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <table style="font-size:14px;width: 100%">
                <tr>
                    <th style="width: 12rem;"></th>
                    <td style="width: 11rem;"></td>
                    <th align="right">Total &emsp;</th>
                    <td><?php echo e(rupiah($total)); ?></td>
                </tr>
            </table>
        </div>

        

        <div class="image-container">
            <img src="https://images.unsplash.com/photo-1644329770639-1a20809b82a3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=945&q=80" alt="">
            <img src="https://images.unsplash.com/photo-1644411370675-e4e4572fc169?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" alt="">
            <img src="https://images.unsplash.com/photo-1640622307911-ee5870412ab5?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" alt="">
            <img src="https://images.unsplash.com/photo-1644333192086-60154e540a11?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=871&q=80" alt="">
        </div>
    </div>


    
    
</body>

</html>
<?php /**PATH E:\Urgen\Backup-11-Des-21\htdocs-1\laravel\Pencucian-Mobil\backend\v3-2022\resources\views/finance/orderan/struk.blade.php ENDPATH**/ ?>