
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card mt-5">
      <div class="card-header">
        Ini Halaman Admin
      </div>      
      <?php
        // dd($jumlah_per_layanan)
      ?>
      <div class="card-body">
        <div class="row">
          <div class="col-md-3 col-sm-4 col-xs-6">
            <div class="card text-center">
              <div class="card-header bg-warning text-white">Semua Orderan</div>
              <div class="card-body">
                <h1><?php echo e($jumlah_semua_orderan); ?></h1>
              </div>
            </div>
          </div>
          
          <?php $__empty_1 = true; $__currentLoopData = $jumlah_per_layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>          
          <div class="col-md-3 col-sm-4 col-xs-6">
            <div class="card text-center">
              <div class="card-header bg-warning text-white"><?php echo e("Orderan ".$item['nama_layanan']); ?></div>
              <div class="card-body">
                <h1><?php echo e($item['jumlah']); ?></h1>
              </div>
            </div>
          </div>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
          <?php endif; ?>
          <div class="col-md-3 col-sm-4 col-xs-6">
            <div class="card text-center">
              <div class="card-header bg-warning text-white">Pemasukan</div>
              <div class="card-body">
                <h1><?php echo e(rupiah($pemasukan)); ?></h1>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stra2734/public_html/hdcarwash2.my.id/resources/views/admin/awal/index.blade.php ENDPATH**/ ?>