<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pencucian Mobil</title>
  <link rel="stylesheet" href="<?php echo e(asset('bootstrap/bootstrap-mod-pulse.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('font-awesome/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/style.css')); ?>">
  <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/png" sizes="16x16">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
  
  <div class="container">
    
    <?php echo $__env->yieldContent('content'); ?>    
    
  </div>
  

  
  
  
  <?php if(auth()->guard()->check()): ?>
  <?php if(Auth::user()->akses == 2): ?>
    <footer class="footer fixed-bottom bg-primary">
      <div class="container">
        <div class="menu">    
          <a href="<?php echo e(url('/finance/orderan')); ?>">
            <i class="fa fa-calendar-check-o"></i>
          </a>
          <a href="<?php echo e(url('/finance/pendapatan')); ?>">
            <i class="fa fa-money"></i>
          </a>
          <a href="<?php echo e(url('/finance/cari')); ?>">
            <i class="fa fa-search"></i>
          </a>
          <a href="<?php echo e(url('/finance/home')); ?>">
            <i class="fa fa-user"></i>
          </a>
          
        </div>
      </div>
    </footer>
  <?php else: ?>
    <footer class="footer fixed-bottom bg-primary">
      <div class="container">
        <div class="menu">    
          <a href="<?php echo e(url('/user/orderan')); ?>">
            <i class="fa fa-calendar-check-o"></i>
          </a>
          <a href="<?php echo e(url('/user/orderan/baru')); ?>">
            <i class="fa fa-plus"></i>
          </a>
          <a href="<?php echo e(url('user/cari')); ?>">
            <i class="fa fa-search"></i>
          </a>
          <a href="<?php echo e(url('user/home')); ?>">
            <i class="fa fa-user"></i>
          </a>
          
        </div>
      </div>
    </footer>
  <?php endif; ?>
  <?php endif; ?>
  
  <script src="<?php echo e(asset('bootstrap/js/jquery-3.0.0.js')); ?>"></script>
  <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>

  <?php echo $__env->yieldPushContent('custom-script'); ?>
</body>
</html><?php /**PATH E:\Urgen\Backup-11-Des-21\htdocs-1\laravel\Pencucian-Mobil\backend\v3-2022\resources\views/mobile/base.blade.php ENDPATH**/ ?>