

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="card mt-5 mb-3">
    <h3 class="card-header bg-primary text-white fixed-top">
      <i class="fa fa-file-text-o"></i> Laporan Pendapatan
    </h3>
    <div class="card-body">
      <form action="<?php echo e(url('finance/pendapatan/filter')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-row">
          <div class="form-group col-md-4">Hasil Filter Data Orderan</div>
          <?php
            if (isset($tanggal)){
              echo 'Tanggal '.date('d-m-Y', strtotime($tanggal));
            } else if (isset($tglmulai) && isset($tglakhir)){
              echo 'Tanggal '.date('d-m-Y', strtotime($tglmulai)).' sampai dengan Tanggal '.date('d-m-Y', strtotime($tglakhir));              
            }
          ?>              
        </div>      
          <br/>
          <div class='form-row'>
            <div class="form-group col-md-4">
              Tampilkan Data Berdasarkan Rentang Tanggal
            </div>
            <div class="form-group col-md-3">
              <input type="date" name="tglmulai" id="tglmulai" class="form-control">
            </div>
            <div class="form-group col-md-3">
              <input type="date" name="tglakhir" id="tglakhir" class="form-control">
            </div>
            <div class="form-group col-md-1">
              <button type="submit" class="btn btn-danger">Tampilkan</button>
            </div>
        </div>
      </form>

      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
          <a href="#home" class="nav-link active" id="home-tab" data-toggle="tab" role="tab" aria-controls="home" aria-selected="true">Hidrolik 1</a>
        </li>
        <li class="nav-item">
          <a href="#home2" class="nav-link" id="home2-tab" data-toggle="tab" role="tab" aria-controls="home2" aria-selected="true">Hidrolik 2</a>
        </li>
        <li class="nav-item">
          <a href="#home3" class="nav-link" id="home3-tab" data-toggle="tab" role="tab" aria-controls="home3" aria-selected="true">Hidrolik 3</a>
        </li>
      </ul>
      <?php
        $data_hidrolik_1 = $orderan->where('hidrolik_id', 1);
        $data_hidrolik_2 = $orderan->where('hidrolik_id', 2);
        $data_hidrolik_3 = $orderan->where('hidrolik_id', 3);

        $totalHidrolik1 = 0; $totalHidrolik2 = 0; $totalHidrolik3 = 0;
      ?>

      <div class="tab-content">
        <div class="tab-pane active" id="home" role="tabpanel" aria-labelledby="home-tab">
          <div class="table-responsive">
            <table class="table">
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>No HP</th>
                <th>Layanan</th>
                <th>Status</th>
                <th>Subtotal</th>
              </tr>
  
              <?php $__empty_1 = true; $__currentLoopData = $data_hidrolik_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                  $a++;
                  $layanan = detailOrderan($item->id);
                  $status = null;
                  if ($item->status == 0){
                    $status = 'Diproses';
                  } else if ($item->status == 1){
                    $status = 'Diselesaikan';
                  } else {
                    $status = 'Dibatalkan';
                  }
                ?>
                <tr>
                  <td><?php echo e($a); ?></td>
                  <td><?php echo e($item->nama); ?></td>
                  <td><?php echo e("+62".$item->nohp); ?></td>
                  <td>
                    <?php
                    $subTotal = 0;
                    for($i = 0; $i < count($layanan); $i++){
                      $subTotal += $layanan[$i]->harga;
                      if($i != (count($layanan) - 1)){
                        echo $layanan[$i]->nama_layanan.", ";
                      } else {
                        echo $layanan[$i]->nama_layanan;
                      }
                    }
  
                    $totalHidrolik1 += $subTotal;
                  ?>
                  </td>
                  <td><?php echo e($status); ?></td>
                  <td><?php echo e(rupiah($subTotal)); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <th colspan="6"><p class="text-center text-warning">Belum Ada Data</p></th>
                </tr> 
              <?php endif; ?>
              <tr>
                <th colspan="4"></th>
                <th>Total</th>
                <th><?php echo e(rupiah($totalHidrolik1)); ?></th>
              </tr>
            </table>
          </div>
        </div>
        <div class="tab-pane" id="home2" role="tabpanel" aria-labelledby="home2-tab">
          <div class="table-responsive">
            <table class="table">
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>No HP</th>
                <th>Layanan</th>
                <th>Status</th>
                <th>Subtotal</th>
              </tr>
  
              <?php $__empty_1 = true; $__currentLoopData = $data_hidrolik_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                  $a++;
                  $layanan = detailOrderan($item->id);
                  $status = null;
                  if ($item->status == 0){
                    $status = 'Diproses';
                  } else if ($item->status == 1){
                    $status = 'Diselesaikan';
                  } else {
                    $status = 'Dibatalkan';
                  }
                ?>
                <tr>
                  <td><?php echo e($a); ?></td>
                  <td><?php echo e($item->nama); ?></td>
                  <td><?php echo e("+62".$item->nohp); ?></td>
                  <td>
                    <?php
                    $subTotal = 0;
                    for($i = 0; $i < count($layanan); $i++){
                      $subTotal += $layanan[$i]->harga;
                      if($i != (count($layanan) - 1)){
                        echo $layanan[$i]->nama_layanan.", ";
                      } else {
                        echo $layanan[$i]->nama_layanan;
                      }
                    }
  
                    $totalHidrolik2 += $subTotal;
                  ?>
                  </td>
                  <td><?php echo e($status); ?></td>
                  <td><?php echo e(rupiah($subTotal)); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <th colspan="6"><p class="text-center text-warning">Belum Ada Data</p></th>
                </tr> 
              <?php endif; ?>
              <tr>
                <th colspan="4"></th>
                <th>Total</th>
                <th><?php echo e(rupiah($totalHidrolik2)); ?></th>
              </tr>
            </table>
          </div>
        </div>
        <div class="tab-pane" id="home3" role="tabpanel" aria-labelledby="home3-tab">
          <div class="table-responsive">
            <table class="table">
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>No HP</th>
                <th>Layanan</th>
                <th>Status</th>
                <th>Subtotal</th>
              </tr>
  
              <?php $__empty_1 = true; $__currentLoopData = $data_hidrolik_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                  $a++;
                  $layanan = detailOrderan($item->id);
                  $status = null;
                  if ($item->status == 0){
                    $status = 'Diproses';
                  } else if ($item->status == 1){
                    $status = 'Diselesaikan';
                  } else {
                    $status = 'Dibatalkan';
                  }
                ?>
                <tr>
                  <td><?php echo e($a); ?></td>
                  <td><?php echo e($item->nama); ?></td>
                  <td><?php echo e("+62".$item->nohp); ?></td>
                  <td>
                    <?php
                    $subTotal = 0;
                    for($i = 0; $i < count($layanan); $i++){
                      $subTotal += $layanan[$i]->harga;
                      if($i != (count($layanan) - 1)){
                        echo $layanan[$i]->nama_layanan.", ";
                      } else {
                        echo $layanan[$i]->nama_layanan;
                      }
                    }
  
                    $totalHidrolik3 += $subTotal;
                  ?>
                  </td>
                  <td><?php echo e($status); ?></td>
                  <td><?php echo e(rupiah($subTotal)); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <th colspan="6"><p class="text-center text-warning">Belum Ada Data</p></th>
                </tr> 
              <?php endif; ?>
              <tr>
                <th colspan="4"></th>
                <th>Total</th>
                <th><?php echo e(rupiah($totalHidrolik3)); ?></th>
              </tr>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mobile.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stra2734/public_html/hdcarwash1.my.id/resources/views/finance/orderan/byReportFilter.blade.php ENDPATH**/ ?>